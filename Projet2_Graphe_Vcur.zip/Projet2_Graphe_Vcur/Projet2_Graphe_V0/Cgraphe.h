#pragma once
//FICHIER HEADER DE LA CLASSE GRAPHE
#ifndef _CGRAPHE_H_
#define _CGRAPHE_H_ 1

//Biblioth�ques
#include "Csommet.h"


//Exceptions
#define AUCUN_SOMMET 101
#define SOMMET_INTROUVABLE 102

/**
* Classe permettant de faire des operations sur un graphe
*/
class Cgraphe {

private:
	unsigned int uiGRANbSommet;			//entier qui stocke le nombre de sommet du graphe
	Csommet** ppSOMGRATableauSommets;	//tableau qui contient des pointeurs vers des Sommets


public:
	Cgraphe();
	Cgraphe(char cNomFichier[256]);		//permet de cr�er un graphe  a partir d'un nom de fichier

	void GRAAjouterArc(Csommet & SOMSommetDestination, Csommet & SOMSommetDepart);
	void GRAAjouterSommet(Csommet & SOMNouveauSommet);
	void GRAAfficherGraphe();
	Csommet* GRALireTableauSommet(unsigned int uiPosition);
	void GRASupprimerSommet(unsigned int uiSommetASupprimer);
	void GRASupprimerSommet(Csommet & SOMSommetASupprimer);
	void GRAInverserArcs(void);
	unsigned int GRALireNbSommet(void);
};

#endif // !_CGRAPHE_H_
