#include "Cgraphe.h"
#include "Carc.h"
#include "Cfichier.h"
#include "Cexception.h"

#include <cstdlib>
#include <iostream>
using namespace std;


/**
* Constructeur par d�faut
* Instancie un grpahe sans sommet ni arc.
*/
Cgraphe::Cgraphe()
{
	uiGRANbSommet = 0;
}


/**
* Cr�er un graphe a partir d'un nom de fichier
*/
Cgraphe::Cgraphe(char cNomFichier[256])
{
	unsigned int *uiNbArc = new unsigned int();
	unsigned int *uiNbSommet = new unsigned int();
	unsigned int * puiTabNumeroSommet;//; = new unsigned int[3];
	unsigned int ** ppuiTabDestinationArc;
	Cfichier FICFichier1;

	//lire le nb d'arcs et de sommets dans le fichier
	FICFichier1.FICLireNbSomArc(cNomFichier, uiNbArc, uiNbSommet);

	//Allocation tableau des numeros des sommets
	puiTabNumeroSommet = new unsigned int[*uiNbSommet];

	//Allocation tableau des destination des arcs
	ppuiTabDestinationArc = new unsigned int*[*uiNbArc];
	for (unsigned int uiCpt = 0; uiCpt < *uiNbArc; uiCpt++)
	{
		ppuiTabDestinationArc[uiCpt] = new unsigned int[2];
	}

	FICFichier1.FICLireNumeroSommet(cNomFichier, puiTabNumeroSommet, uiNbArc, uiNbSommet);
	FICFichier1.FICLireDestinationArc(cNomFichier, ppuiTabDestinationArc, uiNbArc, uiNbSommet);

	Csommet *SOMNouveauSommet;
	for (unsigned int uiCpt = 0; uiCpt < *uiNbSommet; uiCpt++) 
	{
		uiGRANbSommet++;
		ppSOMGRATableauSommets = (Csommet**)realloc(ppSOMGRATableauSommets, uiGRANbSommet * sizeof(Csommet));

		SOMNouveauSommet = new Csommet(puiTabNumeroSommet[uiCpt]);
		ppSOMGRATableauSommets[uiCpt] = SOMNouveauSommet;
	}

	// ppuiTabDestinationArc
	int iIndexDep;
	int iIndexArr;

	for (unsigned int uiCptLigne = 0; uiCptLigne < *uiNbArc; uiCptLigne++) 
	{
		iIndexDep = -1;
		iIndexArr = -1;
		for (unsigned int uiCptCol = 0; uiCptCol < 2; uiCptCol++) 
		{
			for (unsigned int uiCptSommetGraphe = 0; uiCptSommetGraphe < uiGRANbSommet; uiCptSommetGraphe++)
			{
				if (ppSOMGRATableauSommets[uiCptSommetGraphe]->SOMLireSommet() == ppuiTabDestinationArc[uiCptLigne][uiCptCol]) {
					if (iIndexDep == -1) {
						iIndexDep = uiCptSommetGraphe;
					}
					else {
						iIndexArr = uiCptSommetGraphe;
					}
				}
			}
		}
		// On ajoute l'arc
		if ((iIndexDep != -1) && (iIndexArr != -1)) {
			this->GRAAjouterArc(*ppSOMGRATableauSommets[iIndexDep], *ppSOMGRATableauSommets[iIndexArr]);
		}
	}

}


/**
* Ajouter un sommet au graphe 
* @param SOMNouveauSommet r�f�rence vers le sommet � ajouter
*/
void Cgraphe::GRAAjouterSommet(Csommet & SOMNouveauSommet) 
{
	//on incremente le nombre de sommet dans le graphe
	uiGRANbSommet++;
	//on rajoute une case dans le tableau
	ppSOMGRATableauSommets = (Csommet**)realloc(ppSOMGRATableauSommets, uiGRANbSommet * sizeof(Csommet));
	//on cree le pointeur vers le sommet que nous allons ajouter dan le tableau

	ppSOMGRATableauSommets[uiGRANbSommet - 1] = &SOMNouveauSommet;
	//return &SOMNouveauSommet;
}


/**
* Ajouter un arc dans le graphe
* @param SOMSommetDepart Le sommet de d�part de l'arc
* @param SOMSommetDestination Le sommet d'arriv� de l'arc
*/
void Cgraphe::GRAAjouterArc(Csommet & SOMSommetDepart, Csommet & SOMSommetDestination) 
{
	//On instancie un nouvel Arc
	Carc * NouvelArc;
	NouvelArc = new Carc(SOMSommetDestination.SOMLireSommet(), SOMSommetDepart.SOMLireSommet());

	//On ajoute l'arc dans les tableau des arcs patants du sommet de depart
	//et dans le tableau des arcs arrivants du sommet d'arriv�
	//Peut �chouer si un arc pointant d�j� vers cette destination existe d�j� dans le tableau des arcs partants du sommet de depart
	if (SOMSommetDepart.SOMAjouteArcPartant(*NouvelArc)) {
		SOMSommetDestination.SOMAjouteArcArrivant(*NouvelArc);
	}
	else {
		//exception
	}
}


/**
* Afficher le graphe dans la console
*/
void Cgraphe::GRAAfficherGraphe() 
{
	for (unsigned int uiCpt = 0; uiCpt < uiGRANbSommet; uiCpt++) {
		if (ppSOMGRATableauSommets[uiCpt]->SOMLireTailleTabPartant() == 0) {
			cout << "Le sommet " << (ppSOMGRATableauSommets[uiCpt])->SOMLireSommet() << " ne pointe aucun sommet";
			cout << endl;
		}
		else {
			cout << "Le sommet " << (ppSOMGRATableauSommets[uiCpt])->SOMLireSommet() << " pointe les sommets : ";
			(ppSOMGRATableauSommets[uiCpt])->SOMAfficherPartant();
		}

		

		cout << "Le sommet " << (ppSOMGRATableauSommets[uiCpt])->SOMLireSommet() << " est pointe par  : ";
		(ppSOMGRATableauSommets[uiCpt])->SOMAfficherNbArrivant();
		cout << " sommet(s)" << endl;
		cout << endl;

	}

}


/**
* Lire un sommet � une position pr�cise dans le tableau des sommets du graphe
* @param uiPosition La position a laquelle le sommet se trouve dans le tableau
* @return Csommet* - un pointeur vers le sommet a la position donn�e
*/
Csommet * Cgraphe::GRALireTableauSommet(unsigned int uiPosition)
{
	return ((ppSOMGRATableauSommets[uiPosition]));
}


/**
* Supprimer un sommet du graphe
* @param uiSommetASupprimer Le num�ro du sommet � supprimer
*/
void Cgraphe::GRASupprimerSommet(unsigned int uiSommetASupprimer)
{
	if (uiGRANbSommet == 0)
	{	
		Cexception EXCAucunSommet;
		EXCAucunSommet.EXCModifierValeur(AUCUN_SOMMET);
		throw(EXCAucunSommet);
	}

	//On chercher d'abord l'index ou se trouve le sommet 
	bool SommetPresent = false;
	int iIndex = -1;
	for (unsigned int uiCpt = 0; uiCpt < uiGRANbSommet; uiCpt++) 
	{
		if (uiSommetASupprimer == ppSOMGRATableauSommets[uiCpt]->SOMLireSommet()) 
		{
			SommetPresent = true;
			iIndex = uiCpt;
		}
	}

	//on verifie qu'il est pr�sent avant de continuer
	if (SommetPresent == true) {
		//pour chaque sommet du graphe on efface ses arc partant etarrivant vers le sommet 
		for (unsigned int uiCpt = 0; uiCpt < uiGRANbSommet; uiCpt++)
		{
			//suppression des arcs partants
			unsigned int uiNbPartant = ppSOMGRATableauSommets[uiCpt]->SOMLireTailleTabPartant();
			for (unsigned int uiCptPartant = 0; uiCptPartant < uiNbPartant; uiCptPartant++)
			{
				//if (ppSOMGRATableauSommets[uiCpt]->SOMLireArcPartant(uiCptPartant).ARCLireDestination() == uiSommetASupprimer) {
				if (ppSOMGRATableauSommets[uiCpt]->SOMLireArcPartant(uiCptPartant)->ARCLireDestination() == uiSommetASupprimer) {
					ppSOMGRATableauSommets[uiCpt]->SOMSupprimerArcPartant(uiCptPartant);
				}
			}
			//cout << "Affichage du graphe avant de continuer "<<endl;
			//this->GRAAfficherGraphe();
			//suppression des arcs arrivants
			unsigned int uiNbArrivant = ppSOMGRATableauSommets[uiCpt]->SOMLireTailleTabArrivant();
			for (unsigned int uiCptArrivant = 0; uiCptArrivant < uiNbArrivant; uiCptArrivant++)
			{
				if (ppSOMGRATableauSommets[uiCpt]->SOMLireArcArrivant(uiCptArrivant)->ARCLireDepart() == uiSommetASupprimer) {
					ppSOMGRATableauSommets[uiCpt]->SOMSupprimerArcArrivant(uiCptArrivant);
				}

			}
		}

		//ppSOMGRATableauSommets[uiCpt]->SOMSupprimerSommet();
		//ppSOMGRATableauSommets[iIndex]->SOMSupprimerArcPartant();
		//ppSOMGRATableauSommets[iIndex]->SOMSupprimerArcArrivant();
		delete ppSOMGRATableauSommets[iIndex];
		uiGRANbSommet--;
		for (unsigned int uiCptSommet = iIndex; uiCptSommet < uiGRANbSommet; uiCptSommet++) {
			ppSOMGRATableauSommets[uiCptSommet] = ppSOMGRATableauSommets[uiCptSommet + 1];
		}
		ppSOMGRATableauSommets = (Csommet**)realloc(ppSOMGRATableauSommets, (uiGRANbSommet) * sizeof(Csommet*));
	}
	else
	{
		Cexception EXCSommetIntrouvable;
		EXCSommetIntrouvable.EXCModifierValeur(SOMMET_INTROUVABLE);
		throw(EXCSommetIntrouvable);
	}


}


/**
* Surcharge de la m�thode de suppression d'un sommet
* @param &SOM - r�f�rence vers le sommet � supprimer
*/
void Cgraphe::GRASupprimerSommet(Csommet & SOMSommetASupprimer)
{
	this->GRASupprimerSommet(SOMSommetASupprimer.SOMLireSommet());
}

void Cgraphe::GRAInverserArcs(void) 
{

//	ppSOMGRATableauSommets[0]->SOMModifierArc();

	//cout << "dest arc "<< ppSOMGRATableauSommets[0]->SOMLireArcPartant(0)->ARCLireDestination() << endl;
	//cout << "dep arc " << ppSOMGRATableauSommets[0]->SOMLireArcPartant(0)->ARCLireDepart() << endl;

	//cout << "dest arc " << ppSOMGRATableauSommets[0]->SOMLireArcPartant(1)->ARCLireDestination() << endl;
	//cout << "dep arc " << ppSOMGRATableauSommets[0]->SOMLireArcPartant(1)->ARCLireDepart() << endl;

	//ppSOMGRATableauSommets[0]->SOMLireArcPartant(0)->ARCInverserArc();

	//cout << "dest arc " << ppSOMGRATableauSommets[0]->SOMLireArcPartant(0)->ARCLireDestination() << endl;
	//cout << "dep arc " << ppSOMGRATableauSommets[0]->SOMLireArcPartant(0)->ARCLireDepart() << endl;

	for (unsigned int uiCptSommet = 0; uiCptSommet < uiGRANbSommet; uiCptSommet++)
	{
		ppSOMGRATableauSommets[uiCptSommet]->SOMInverserArc();

		unsigned int nbPartant = ppSOMGRATableauSommets[uiCptSommet]->SOMLireTailleTabPartant();
		for (unsigned int uiCptPartant = 0; uiCptPartant < nbPartant; uiCptPartant++)
		{
			//cout << ppSOMGRATableauSommets[uiCptPartant]->SOMLireArcPartant(uiCptPartant).ARCLireDestination()<<" ";
			ppSOMGRATableauSommets[uiCptSommet]->SOMLireArcPartant(uiCptPartant)->ARCInverserArc();
		}
		
		//unsigned int nbArrivant = ppSOMGRATableauSommets[uiCptSommet]->SOMLireTailleTabArrivant();
		//for (unsigned int uiCptArrivant = 0; uiCptArrivant < nbArrivant; uiCptArrivant++)
		//{
			//ppSOMGRATableauSommets[uiCptArrivant]->SOMLireArcArrivant(uiCptArrivant)->ARCInverserArc();
		//}

		//if (SOMSommetDepart.SOMAjouteArcPartant(*NouvelArc)) {
		//	SOMSommetDestination.SOMAjouteArcArrivant(*NouvelArc);
		//}
		//else {
		//	//exception
		//}
		
	}
	
	/*
	cout << "Le sommet " << (ppSOMGRATableauSommets[uiCpt])->SOMLireSommet() << " pointe les sommets : ";
	(ppSOMGRATableauSommets[uiCpt])->SOMAfficherPartant();
	cout << "Le sommet " << (ppSOMGRATableauSommets[uiCpt])->SOMLireSommet() << " est pointe par  : ";
	(ppSOMGRATableauSommets[uiCpt])->SOMAfficherNbArrivant();
	cout << " sommet(s)" << endl;
	cout << endl;*/


}

unsigned int Cgraphe::GRALireNbSommet(void)
{
	return uiGRANbSommet;
}
