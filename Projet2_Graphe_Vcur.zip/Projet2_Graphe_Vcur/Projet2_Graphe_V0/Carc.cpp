#include <iostream>
#include "Carc.h"

using namespace std;

Carc::Carc()
{
	uiARCDestination = 0;
}


Carc::Carc(unsigned int uiDestination, unsigned int uiDepart)
{
	uiARCDestination = uiDestination;
	uiARCDepart = uiDepart;
}


//Carc::~Carc()
//{
//}


unsigned int Carc::ARCLireDestination()
{
	return uiARCDestination;
}


unsigned int Carc::ARCLireDepart()
{
	return uiARCDepart;
}

void Carc::ARCModifierDestination(unsigned int uiNouvelDestination)
{
	uiARCDestination = uiNouvelDestination;
}


void Carc::ARCModifierDepart(unsigned int uiNouveauDepart)
{
	uiARCDepart = uiNouveauDepart;
}

void Carc::ARCInverserArc(void) 
{
	unsigned int uiTempDepart = uiARCDepart;
	uiARCDepart = uiARCDestination;
	uiARCDestination = uiTempDepart;
}
