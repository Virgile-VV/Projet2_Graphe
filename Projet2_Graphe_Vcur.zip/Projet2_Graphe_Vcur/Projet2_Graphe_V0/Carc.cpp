#include <iostream>
#include "Carc.h"

using namespace std;

Carc::Carc()
{
	uiARCDestination = 0;
}


/**
* Instancie un nouvel Arc
* pr�-condition les unsigned int doivent �tre des num�ro de sommet d�j� pr�sent dans le graphe
*/
Carc::Carc(unsigned int uiDestination, unsigned int uiDepart)
{
	uiARCDestination = uiDestination;
	uiARCDepart = uiDepart;
}


/**
* Retourne la valeur du sommet de destination de l'arc
* @return (unsigned int)
*/
unsigned int Carc::ARCLireDestination()
{
	return uiARCDestination;
}


/**
* Retourne la valeur du sommet de d�part de l'arc
* @return (unsigned int)
*/
unsigned int Carc::ARCLireDepart()
{
	return uiARCDepart;
}


/**
* Modifie la destination de l'arc
* pr�-condition : la valeur doit etre le numero d'un sommet d�j� pr�sent dans le graphe
* @param uiNouvelDestination (unsigned int) Valeur de la nouvelle destination 
*/
void Carc::ARCModifierDestination(unsigned int uiNouvelDestination)
{
	uiARCDestination = uiNouvelDestination;
}

/**
* Modifie le d�part de l'arc
* pr�-condition : la valeur doit etre le numero d'un sommet d�j� pr�sent dans le graphe
* @param uiNouveauD�part (unsigned int) Valeur du nouveau sommet de d�part
*/
void Carc::ARCModifierDepart(unsigned int uiNouveauDepart)
{
	uiARCDepart = uiNouveauDepart;
}


/**
* Inverse les valeurs de destination et de d�part
*/
void Carc::ARCInverserArc(void) 
{
	unsigned int uiTempDepart = uiARCDepart;
	uiARCDepart = uiARCDestination;
	uiARCDestination = uiTempDepart;
}


/**
* Surcharge de l'operateur= 
*/
void Carc::operator=(Carc & ARCParam)
{
	uiARCDestination = ARCParam.ARCLireDestination();
	uiARCDepart = ARCParam.ARCLireDepart();
}
