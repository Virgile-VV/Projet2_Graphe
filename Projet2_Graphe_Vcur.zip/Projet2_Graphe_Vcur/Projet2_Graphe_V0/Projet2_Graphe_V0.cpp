// Projet2_Graphe_V0.cpp : Ce fichier contient la fonction 'main'. L'exécution du programme commence et se termine à cet endroit.
//

#include <iostream>
#include "Cgraphe.h"	//1
#include "Csommet.h"	//2
#include "Carc.h"		//3
#include "Cfichier.h"	//4
#include "Cexception.h" //5
using namespace std;

#define AUCUN_FICHIER 1

int main(int argc, char *argv[])
{
	try
	{
		if (argc == 1) {
			Cexception EXCAucunFichier;
			EXCAucunFichier.EXCModifierValeur(AUCUN_FICHIER);
			throw(EXCAucunFichier);
		}

		cout << "Graphe dans le fichier :" << endl << endl;
		Cgraphe GRAFichier(argv[1]);
		
		//GRAFichier.GRASupprimerSommet(3);

		GRAFichier.GRAAfficherGraphe();


		cout << "Inverse graphe : " << endl << endl;
		//La fonction GRAInverseArcs ne renvoie pas un nouveau graphe, 
		//il faut donc copier le premier dans un autre graphe avant
		Cgraphe GRAInverse;
		Cgraphe GRAInverse2;
		GRAInverse = GRAFichier;

		GRAInverse = GRAInverse.GRAInverserArcs();
		cout << "graphe inverse "<<endl;

		GRAInverse.GRAAfficherGraphe();

	}
	catch (Cexception EXClevee)
	{
		EXClevee.EXCAfficherException();
	}
}
