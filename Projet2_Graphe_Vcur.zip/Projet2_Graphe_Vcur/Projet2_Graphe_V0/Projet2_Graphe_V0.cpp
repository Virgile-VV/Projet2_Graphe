// Projet2_Graphe_V0.cpp : Ce fichier contient la fonction 'main'. L'exécution du programme commence et se termine à cet endroit.
//

#include <iostream>
#include "Cgraphe.h"	//1
#include "Csommet.h"	//2
#include "Carc.h"		//3
#include "Cfichier.h"	//4
#include "Cexception.h" //5
using namespace std;


int main(int argc, char *argv[])
{
	try {

		std::cout << "Hello Virgile!\n";

		Cgraphe GRA1(argv[1]);

		GRA1.GRAAfficherGraphe();


		cout << "Suppression du sommet 1 :" << endl;
		//GRA1.GRASupprimerSommet(1);
		//GRA1.GRASupprimerSommet(3);
		//GRA1.GRAAfficherGraphe();
		//GRA1.GRAAfficherGraphe();

		/*
		Cgraphe graphe1;
		Csommet SOMdepart(10);
		Csommet SOMarrive(20);
		Csommet SOMarrive2(30);
		Csommet SOMarrive3(40);
		Csommet SOMdepart4(50);

		graphe1.GRAAjouterSommet(SOMdepart);
		graphe1.GRAAjouterSommet(SOMarrive);
		graphe1.GRAAjouterSommet(SOMarrive2);
		graphe1.GRAAjouterSommet(SOMarrive3);
		graphe1.GRAAjouterSommet(SOMdepart4);

		graphe1.GRAAjouterArc(SOMdepart, SOMarrive);
		graphe1.GRAAjouterArc(SOMdepart, SOMarrive2);
		graphe1.GRAAjouterArc(SOMdepart, SOMarrive3);
		graphe1.GRAAjouterArc(SOMdepart4, SOMdepart);

		cout << endl;

		//SOMdepart.SOMSupprimerArcArrivant();

		cout << "afficher graphe :" << endl;
		graphe1.GRAAfficherGraphe();
		graphe1.GRASupprimerSommet(SOMdepart);
		cout << "afficher graphe :" << endl;
		graphe1.GRAAfficherGraphe();
		*/
		cout << endl;
		cout << "Inverse graphe : ";
		cout << endl;
		GRA1.GRAInverserArcs();

		GRA1.GRAAfficherGraphe();

	}
	catch (Cexception EXClevee) {
		EXClevee.EXCAfficherException(EXClevee.EXCLireValeur());
	}

}
