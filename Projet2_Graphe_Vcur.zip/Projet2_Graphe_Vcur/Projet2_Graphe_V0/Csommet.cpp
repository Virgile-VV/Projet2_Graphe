#include <cstdlib>
#include <iostream>
#include "Csommet.h" //2
#include "Cexception.h" //5
using namespace std;

/**
* Constructeur par d�faut
*/
Csommet::Csommet() {
	uiSOMNbPartant = 0;
	uiSOMNbArrivant = 0;
}


/**
* Constructeur
*/
Csommet::Csommet(unsigned int uiNumeroSommet) {
	uiSOMNumero = uiNumeroSommet;
	uiSOMNbPartant = 0;
	uiSOMNbArrivant = 0;
}


/**
* pr�-condition : m�thode a appeler dans le destructeur de Cgraphe
* d�salloue tout le tableau des arcs partants
*/
void Csommet::desallocSOMTableauPartant(void)
{
	// On d�salloue les pointeurs contenu dans le tableau des arcs partants
	for (unsigned int uiCpt = 0; uiCpt < uiSOMNbPartant; uiCpt++) {
		if (ppARCSOMPartant[uiCpt] != nullptr) {
			delete ppARCSOMPartant[uiCpt];
			ppARCSOMPartant[uiCpt] = nullptr;
		}
	}
	// On d�salloue le tableau et on met son compteur a 0
	delete[] ppARCSOMPartant;
	ppARCSOMPartant = nullptr;
	uiSOMNbPartant = 0;

}

/**
* pr�-condition : m�thode a appeler dans le destructeur de Cgraphe apr�s la m�thode desallocSOMTableauPartant
* d�salloue le tableau des arcs arrivants sans d�sallouer les cases une par une 
* car elles contiennent des objets d�j� d�sallou� par la m�thode desallocTableauPartant donc il y aurait des erreurs
*/
void Csommet::desallocSOMTableauArrivant(void)
{
	// On d�salloue le tableau des arcs partants et on met son compteur a 0
	delete[] ppARCSOMArrivant;
	ppARCSOMArrivant = nullptr;
	uiSOMNbArrivant = 0;
}

/**
* Ajout d'un �l�ment au tableau des arcs partant
* pr�-condition : Cette m�thode doit �tre appel�e en m�me temps que SOMAjouterArcArrivant
* renvoie une exception si l'arc a la m�me destination qu'un autre
*/
void Csommet::SOMAjouteArcPartant(Carc &ARCPartant)
{
	// d'abord on parcours le tableau 
	for (int iCpt = 0; iCpt < uiSOMNbPartant; iCpt++) {
		if (ppARCSOMPartant[iCpt]->ARCLireDestination() == ARCPartant.ARCLireDestination()) {
			Cexception EXCArcExistant;
			EXCArcExistant.EXCModifierValeur(ARC_EXISTANT);
			throw(EXCArcExistant);
		}
	}
	//incrementation du nombre d'arc partant
	uiSOMNbPartant++;

	//reallocation du tableau
	ppARCSOMPartant = (Carc**)realloc(ppARCSOMPartant, uiSOMNbPartant * sizeof(Carc));

	//ajout de l'�l�ment dans la case (somme de tous les partant - 1) puisque le tab commence a 0
	ppARCSOMPartant[uiSOMNbPartant - 1] = &ARCPartant;

}


/**
* Ajout d'un �l�ment au tableau des arcs arrivant
* pr�-condition : Cette m�thode doit �tre appel�e en m�me temps que SOMAjotuerArcPartant 
*/
void Csommet::SOMAjouteArcArrivant(Carc &ARCArrivant)
{
	//incrementation du nombre d'arc partant
	uiSOMNbArrivant++;

	//reallocation du tableau
	ppARCSOMArrivant = (Carc**)realloc(ppARCSOMArrivant, uiSOMNbArrivant * sizeof(Carc));

	//ajout de l'�l�ment dans la case (somme de tous les partant - 1) puisque le tab commence a 0
	ppARCSOMArrivant[uiSOMNbArrivant - 1] = &ARCArrivant;
}


/**
* Lire le numero du sommet qui appelle la m�thode
* return (unsigned int) Le numero du sommet
*/
unsigned int Csommet::SOMLireSommet()
{
	return uiSOMNumero;
}


/**
* Affiche dans la console les arcs partants
*/
void Csommet::SOMAfficherPartant(void)
{
	for (unsigned int uiCpt = 0; uiCpt < uiSOMNbPartant; uiCpt++) {
		if (uiCpt == uiSOMNbPartant - 1) {
			cout << ppARCSOMPartant[uiCpt]->ARCLireDestination();
		}
		else {
			cout << ppARCSOMPartant[uiCpt]->ARCLireDestination() << ", ";
		}
	}
	cout << endl;
}

/**
* Retourne l'arc a la position demand�e dans le tableau des arcs partants
* pr�-condition : uiPositionArc doit etre inf�rieur � la taille du tableau des arcs partants
*
* @return (Carc*) Un pointeur sur un Carc dans le tableau des arcs partants
*/
Carc *Csommet::SOMLireArcPartant(unsigned int uiPositionArc)
{
	return ppARCSOMPartant[uiPositionArc];
}


/**
* Retourne l'arc a la position demand�e dans le tableau des arcs arrivants
* pr�-condition : uiPositionArc doit etre inf�rieur � la taille du tableau des arcs arrivants
*
* @return (Carc *) Un pointeur sur un Carc dans le tableau des arcs arrivants
*/
Carc *Csommet::SOMLireArcArrivant(unsigned int uiPositionArc)
{
	return ppARCSOMArrivant[uiPositionArc];
}

/**
* Retourne la taille du tableau des arcs partants 
* @return (unsigned int)
*/
unsigned int Csommet::SOMLireNbPartant(void)
{
	return uiSOMNbPartant;
}


/**
* Retourne la taille du tableau des arcs arrivants
* @return (unsigned int)
*/
unsigned int Csommet::SOMLireNbArrivant(void)
{
	return uiSOMNbArrivant;
}


/**
* Affiche le nombre d'arrivant dans la console 
*/
void Csommet::SOMAfficherNbArrivant(void)
{
	cout << uiSOMNbArrivant;
}


/**
* Inverse les tableaux d'arcs arrivants et partants 
* Inverse les nombres d'arrivants et de partants
*/
void Csommet::SOMInverserArc() {
	Carc** ppARCArrivantTemp;
	ppARCArrivantTemp = (Carc**)realloc(ppARCSOMArrivant, (uiSOMNbArrivant) * sizeof(Csommet*));
	ppARCSOMArrivant = (Carc**)realloc(ppARCSOMPartant, (uiSOMNbPartant) * sizeof(Csommet*));
	ppARCSOMPartant = (Carc**)realloc(ppARCArrivantTemp, (uiSOMNbArrivant) * sizeof(Csommet*));

	unsigned int uiNbArrivantTemp;
	uiNbArrivantTemp = uiSOMNbArrivant;
	uiSOMNbArrivant = uiSOMNbPartant;
	uiSOMNbPartant = uiNbArrivantTemp;
}

void Csommet::SOMModifierNumero(unsigned int uiNouveauNumero)
{
	uiSOMNumero = uiNouveauNumero;
}


/**
* Supprime un arc dans le tableau des arcs partants a une position donn�e
* D�salloue le pointeur vers l'arc et r�alloue la tableau des arcs partants
* pr�-condition : uiPositionArc < uiSOMNbPartant
* @param uiPositionArc (unsigned int) la position a laquelle on veut supprimer l'arc dans le tableau 
*/
void Csommet::SOMSupprimerArcPartant(unsigned int uiPositionArc)
{
	if (uiSOMNbPartant > 0) {
		for (unsigned int iCpt = uiPositionArc; iCpt < uiSOMNbPartant - 1; iCpt++) {
			ppARCSOMPartant[iCpt] = ppARCSOMPartant[iCpt + 1];
		}
		uiSOMNbPartant = uiSOMNbPartant - 1;
		//delete ppARCSOMPartant[uiSOMNbPartant];
		ppARCSOMPartant = (Carc**)realloc(ppARCSOMPartant, uiSOMNbPartant * sizeof(Carc));
		//delete ppARCSOMPartant[uiSOMNbPartant];
		/*cout << ppARCSOMPartant[0]->ARCLireDestination()<<" ";
		cout << ppARCSOMPartant[1]->ARCLireDestination()<<" ";
		cout << ppARCSOMPartant[2]->ARCLireDestination()<<" ";
		cout << endl;*/

		
	}
}


/**
* Supprime un arc dans le tableau des arcs arrivants a une position donn�e
* D�salloue le pointeur vers l'arc et r�alloue la tableau des arcs arrivants
* pr�-condition : uiPositionArc < uiSOMNbArrivant
* @param uiPositionArc (unsigned int) la position a laquelle on veut supprimer l'arc dans le tableau
*/
void Csommet::SOMSupprimerArcArrivant(unsigned int uiPositionArc)
{
	if (uiSOMNbArrivant > 0) 
	{
		for (unsigned int iCpt = uiPositionArc; iCpt < uiSOMNbArrivant - 1; iCpt++) {
			ppARCSOMArrivant[iCpt] = ppARCSOMArrivant[iCpt + 1];
		}
		uiSOMNbArrivant--;
		ppARCSOMArrivant = (Carc**)realloc(ppARCSOMArrivant, uiSOMNbArrivant * sizeof(Carc));
	}

}

void Csommet::SOMSupprimerArcArrivant(void)
{
	for (unsigned int iCpt = 0; iCpt < uiSOMNbArrivant; iCpt++) {
		delete ppARCSOMArrivant[iCpt];
	}
	delete[] ppARCSOMArrivant;
	uiSOMNbArrivant = 0;
}

void Csommet::SOMSupprimerArcPartant(void)
{
	for (unsigned int iCpt = 0; iCpt < uiSOMNbPartant; iCpt++) {
		delete ppARCSOMPartant[iCpt];
	}
	delete[] ppARCSOMPartant;
	uiSOMNbPartant = 0;
}
