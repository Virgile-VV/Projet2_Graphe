#include <cstdlib>
#include <iostream>
#include "Csommet.h"
using namespace std;

/**
* Constructeur par d�faut
*/
Csommet::Csommet() {
	uiSOMNbPartant = 0;
	uiSOMNbArrivant = 0;
}


/**
* Constructeur
*/
Csommet::Csommet(unsigned int uiNumeroSommet) {
	uiSOMNumero = uiNumeroSommet;
	uiSOMNbPartant = 0;
	uiSOMNbArrivant = 0;
}


/**
* Ajout d'un �l�ment au tableau des arcs partant
*
* renvoie un bool�en
*	true : si l'arc a �t� ajout�
*	false : si l'arc n'a pas �t� ajout�
*/
bool Csommet::SOMAjouteArcPartant(Carc &ARCPartant)
{
	//d'abord on parcours le tableau 
	int iDeuxArcMemeDestination = 0;

	for (int iCpt = 0; iCpt < uiSOMNbPartant; iCpt++) {
		if (ppARCSOMPartant[iCpt]->ARCLireDestination() == ARCPartant.ARCLireDestination()) {
			iDeuxArcMemeDestination = 1;

			cerr << "L'arc poitant vers " << ppARCSOMPartant[iCpt]->ARCLireDestination() << " dans la table des arc partant du sommet" << SOMLireSommet();
			cerr << "n'a pas pu �tre ajout� car un arc pointe deja vers cette destination" << endl;
		}
	}
	if (iDeuxArcMemeDestination == 0) {
		//incrementation du nombre d'arc partant
		uiSOMNbPartant++;

		//reallocation du tableau
		ppARCSOMPartant = (Carc**)realloc(ppARCSOMPartant, uiSOMNbPartant * sizeof(Carc));

		//ajout de l'�l�ment dans la case (somme de tous les partant - 1) puisque le tab commence a 0
		ppARCSOMPartant[uiSOMNbPartant - 1] = &ARCPartant;
		//cout << ppARCSOMPartant[0];
		return true;
	}
	return false;

}


/**
* Ajout d'un �l�ment au tableau des arcs arrivant
*/
void Csommet::SOMAjouteArcArrivant(Carc &ARCArrivant)
{
	//incrementation du nombre d'arc partant
	uiSOMNbArrivant++;

	//reallocation du tableau
	ppARCSOMArrivant = (Carc**)realloc(ppARCSOMArrivant, uiSOMNbArrivant * sizeof(Carc));

	//ajout de l'�l�ment dans la case (somme de tous les partant - 1) puisque le tab commence a 0
	ppARCSOMArrivant[uiSOMNbArrivant - 1] = &ARCArrivant;
}


/**
* Lire le numero du sommet qui appelle la m�thode
* Renvoie un unsigned int : Le numero du sommet
*/
unsigned int Csommet::SOMLireSommet()
{
	return uiSOMNumero;
}


/**
* Affiche dans la console les arcs partants
*/
void Csommet::SOMAfficherPartant(void)
{
	for (unsigned int uiCpt = 0; uiCpt < uiSOMNbPartant; uiCpt++) {
		if (uiCpt == uiSOMNbPartant - 1) {
			cout << ppARCSOMPartant[uiCpt]->ARCLireDestination();
		}
		else {
			cout << ppARCSOMPartant[uiCpt]->ARCLireDestination() << ", ";
		}
	}
	cout << endl;
}

/**
* Retourne l'arc a la position demand�e dans le tableau des arcs partants
*/
Carc *Csommet::SOMLireArcPartant(unsigned int uiPositionArc)
{
	return ppARCSOMPartant[uiPositionArc];
}


/**
* Retourne l'arc a la position demand�e dans le tableau des arcs arrivants
*/
Carc *Csommet::SOMLireArcArrivant(unsigned int uiPositionArc)
{
	return ppARCSOMArrivant[uiPositionArc];
}

unsigned int Csommet::SOMLireTailleTabPartant(void)
{
	return uiSOMNbPartant;
}


unsigned int Csommet::SOMLireTailleTabArrivant(void)
{
	return uiSOMNbArrivant;
}


/**
* Affiche le nombre d'arrivant dans la console 
*/
void Csommet::SOMAfficherNbArrivant(void)
{
	cout << uiSOMNbArrivant;
	/*for (unsigned int uiCpt = 0; uiCpt < uiSOMNbArrivant; uiCpt++) {
		cout << ppARCSOMArrivant[uiCpt]->ARCLireDestination() << ", ";
	}
	cout << endl;*/
}


/**
* Inverse les tableaux d'arcs arrivants et partants 
* Inverse les nombres d'arrivants et de partants
*/
void Csommet::SOMInverserArc() {
	Carc** ppARCArrivantTemp;
	ppARCArrivantTemp = (Carc**)realloc(ppARCSOMArrivant, (uiSOMNbArrivant) * sizeof(Csommet*));
	ppARCSOMArrivant = (Carc**)realloc(ppARCSOMPartant, (uiSOMNbPartant) * sizeof(Csommet*));
	ppARCSOMPartant = (Carc**)realloc(ppARCArrivantTemp, (uiSOMNbArrivant) * sizeof(Csommet*));

	unsigned int uiNbArrivantTemp;
	uiNbArrivantTemp = uiSOMNbArrivant;
	uiSOMNbArrivant = uiSOMNbPartant;
	uiSOMNbPartant = uiNbArrivantTemp;
}


void Csommet::SOMSupprimerSommet()
{
	//for (unsigned int iCpt = 0; iCpt < uiSOMNbArrivant; iCpt++) {
	//	delete ppARCSOMArrivant[iCpt];
	//}
	//delete[] ppARCSOMArrivant;
	//uiSOMNbArrivant = 0;
}


void Csommet::SOMSupprimerArcPartant(unsigned int uiPositionArc)
{
	if (uiSOMNbPartant > 0) {
		//delete ppARCSOMPartant[uiPositionArc];
		for (unsigned int iCpt = uiPositionArc; iCpt < uiSOMNbPartant - 1; iCpt++) {
			ppARCSOMPartant[iCpt] = ppARCSOMPartant[iCpt + 1];
		}
		uiSOMNbPartant--;
		ppARCSOMPartant = (Carc**)realloc(ppARCSOMPartant, uiSOMNbPartant * sizeof(Carc));
		//delete ppARCSOMPartant[uiSOMNbPartant];
		/*cout << ppARCSOMPartant[0]->ARCLireDestination()<<" ";
		cout << ppARCSOMPartant[1]->ARCLireDestination()<<" ";
		cout << ppARCSOMPartant[2]->ARCLireDestination()<<" ";
		cout << endl;*/

		
	}
}

void Csommet::SOMSupprimerArcArrivant(unsigned int uiPositionArc)
{
	if (uiSOMNbArrivant > 0) {
		//delete ppARCSOMArrivant[uiPositionArc];
		for (unsigned int iCpt = uiPositionArc; iCpt < uiSOMNbArrivant - 1; iCpt++) {
			ppARCSOMArrivant[iCpt] = ppARCSOMArrivant[iCpt + 1];
		}
		uiSOMNbArrivant--;
		ppARCSOMArrivant = (Carc**)realloc(ppARCSOMArrivant, uiSOMNbArrivant * sizeof(Carc));
		//delete ppARCSOMPartant[uiSOMNbArrivant];
	}

}

void Csommet::SOMSupprimerArcArrivant(void)
{
	for (unsigned int iCpt = 0; iCpt < uiSOMNbArrivant; iCpt++) {
		delete ppARCSOMArrivant[iCpt];
	}
	delete[] ppARCSOMArrivant;
	uiSOMNbArrivant = 0;
}

void Csommet::SOMSupprimerArcPartant(void)
{
	for (unsigned int iCpt = 0; iCpt < uiSOMNbPartant; iCpt++) {
		delete ppARCSOMPartant[iCpt];
	}
	delete[] ppARCSOMPartant;
	uiSOMNbPartant = 0;
}