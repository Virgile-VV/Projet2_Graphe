#pragma once
//FICHIER HEADER DE LA CLASSE EXCEPTION
#ifndef EXCEPTION_H_
#define EXCEPTION_H_ 5


class Cexception
{
private:

	//attributs
	unsigned int uiEXCValeur;


public:

	//constructeur
	Cexception();

	//methodes
	void EXCModifierValeur(unsigned int uiEXCNouvelleValeur);
	unsigned int EXCLireValeur();
	void EXCAfficherException(unsigned int);
};

#endif /* EXCEPTION_H */