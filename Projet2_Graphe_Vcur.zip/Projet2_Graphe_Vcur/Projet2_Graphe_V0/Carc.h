#pragma once
//FICHIER HEADER DE LA CLASSE ARC
#ifndef _CARC_H_
#define _CARC_H_ 3


/**
* Un arc ne peut pas exister sans sommet
* Un arc est orient� vers un seul sommet,
* si on veut aller de S1 � S2 et de S2 � S1 on devra donc cr�er 2 arcs.
*/
class Carc
{

private:
	unsigned int uiARCDestination;      // le numero de sommet vers lequel pointe l' arc
	unsigned int uiARCDepart;

public:
	Carc();
	Carc(unsigned int uiDestination, unsigned int uiDepart);
	//~Carc();

	unsigned int ARCLireDestination();
	unsigned int ARCLireDepart();
	void ARCModifierDestination(unsigned int NouvelDestination);
	void ARCModifierDepart(unsigned int uiNouveauDepart);
	void ARCInverserArc(void);
	void operator=(Carc & ARCParam);
};


#endif // !_CARC_H_
