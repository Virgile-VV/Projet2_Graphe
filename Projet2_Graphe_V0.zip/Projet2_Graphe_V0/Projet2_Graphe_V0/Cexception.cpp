//FICHIER CPP DE LA CLASSE EXCEPTION
#include "Cexception.h"
#include "iostream"		//affichage dans le terminal
using namespace std;

// --- DECLARATION DE LA CLASSE EXCEPTION ---

/**
* Constructeur par d�faut de Cexception :
* d�clare la valeur de l'excpetion � 0
*/
Cexception::Cexception()
{
	uiEXCValeur = 0;
}


/**
* Accesseur en ecriture de la valeur de l'exception
* @param uiEXCNouvelleValeur La nouvelle valeur d'exception 
* @return void (mais modifie la valeur de l'exception de l'objet qui appelle)
*/
void Cexception::EXCModifierValeur(unsigned int uiEXCNouvelleValeur)
{
	uiEXCValeur = uiEXCNouvelleValeur;
}


/** 
* Accesseur en lecture de la valeur de l'exception
* @return (unsigned int) uiEXCValeur - La valeur de l'exception
*/
unsigned int Cexception::EXCLireValeur()
{
	return uiEXCValeur;
}


/**
* Affiche un message dans la console permettant de comprendre l'exception 
* @param uiException la valeur de l'exception 
*/
void Cexception::EXCAfficherException( void )
{
	switch (uiEXCValeur)
	{
	case 1:
		cerr << "[exception] Aucun fichier en parametre du programme" << endl;
		break;
	case 101:
		cerr << "[exception] Aucun sommet dans le graphe (voir Cgraphe.h)" << endl;
		break;
	case 102:
		cerr << "[exception] Suppression introuvable dans le graphe (voir Cgraphe.h)" << endl;
		break;
	case 103:
		cerr << "[exception] Un sommet avec la meme destination se trouve d�j� dans le graphe (voir Cgraphe.h)" << endl;
		break;
	case 201:
		cerr << "[exception] L'arc n'a pas pu �tre ajout� car il a la m�me destination qu'un autre d�j� existant voir Csommet.h)" << endl;
		break;
	case 401:
		cerr << "[exception] Ouverture du fichier impossible (voir Cfichier.h)" << endl;
		break;

	default:
		cerr << "[exception]";
		break;
	}
}