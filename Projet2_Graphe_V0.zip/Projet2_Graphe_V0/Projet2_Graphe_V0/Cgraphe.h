#pragma once
//FICHIER HEADER DE LA CLASSE GRAPHE
#ifndef _CGRAPHE_H_
#define _CGRAPHE_H_ 1

//Biblioth�ques
#include "Csommet.h"


//Exceptions
#define AUCUN_SOMMET 101
#define SOMMET_INTROUVABLE 102
#define SOMMET_EXISTANT 103

/**
* Classe permettant de faire des operations sur un graphe
*/
class Cgraphe {

private:
	unsigned int uiGRANbSommet;			//entier qui stocke le nombre de sommet du graphe
	Csommet** ppSOMGRATableauSommets;	//tableau qui contient des pointeurs vers des Sommets


public:
	// Constructeurs :
	Cgraphe();
	Cgraphe(char cNomFichier[256]);
	Cgraphe(Cgraphe & GRAGrapheACopier);
	~Cgraphe();
	// Methode :
	// Ajout
	void GRAAfficherGraphe();
	void GRAAjouterArc(Csommet & SOMSommetDestination, Csommet & SOMSommetDepart);
	void GRAAjouterSommet(Csommet & SOMNouveauSommet);
	unsigned int GRALireNbSommet(void) const;
	void GRASupprimerSommet(unsigned int uiSommetASupprimer);
	void GRASupprimerSommet(Csommet & SOMSommetASupprimer);
	void GRAModifierSommet(unsigned int uiPosition, unsigned int uiNouvelleValeur);
	Csommet* GRALireTableauSommet(unsigned int uiPosition) const;
	Cgraphe GRAInverserArcs(void);
	// Surcharge :
	void operator=(const Cgraphe & GRAGrapheACopier);

};

#endif // !_CGRAPHE_H_
