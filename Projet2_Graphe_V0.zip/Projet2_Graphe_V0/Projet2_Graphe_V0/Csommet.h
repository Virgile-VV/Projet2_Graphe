﻿#pragma once
//FICHIER HEADER DE LA CLASSE ARC
#ifndef _CSOMMET_H_
#define _CSOMMET_H_ 2

#include "Carc.h"

// Exceptions :
#define ARC_EXISTANT 201

/**
* Classe permettant de gérer des sommets
*/
class Csommet
{

private:
	unsigned int uiSOMNumero;
	Carc ** ppARCSOMArrivant;
	Carc ** ppARCSOMPartant;
	unsigned int uiSOMNbPartant;
	unsigned int uiSOMNbArrivant;

public:
	
	Csommet(); //ne fait rien
	Csommet(unsigned int uiNumeroSommet);
	void desallocSOMTableauPartant(void);
	void desallocSOMTableauArrivant(void);

	//methodes
	//methode pour le sommet
	unsigned int SOMLireSommet();
	void SOMInverserArc(void);
	void SOMModifierNumero(unsigned int uiNouveauNumero);

	//methode sur son tableau d'arc partant
	void SOMAjouteArcPartant(Carc &ARCPartant);
	void SOMAfficherPartant(void);
	unsigned int SOMLireNbPartant(void);
	Carc* SOMLireArcPartant(unsigned int);
	void SOMSupprimerArcPartant(unsigned int);
	void SOMModifierArcPartant(unsigned int uiPosition, unsigned int uiNouvelleDestination);

	//methode sur son tableau d'arc arrivant
	void SOMAjouteArcArrivant(Carc &ARCArrivant);
	void SOMAfficherNbArrivant(void);
	unsigned int SOMLireNbArrivant(void);
	Carc* SOMLireArcArrivant(unsigned int);
	void SOMSupprimerArcArrivant(unsigned int);
	void SOMModifierArcArrivant(unsigned int uiPosition, unsigned int uiNouvelleDestination);
	//methode pas fini
	void SOMSupprimerArcArrivant(void);
	void SOMSupprimerArcPartant(void);

};

#endif // !_CSOMMET_H_