#include "Cgraphe.h"
#include "Carc.h"
#include "Cfichier.h"
#include "Cexception.h"

#include <cstdlib>
#include <iostream>
using namespace std;


/**
* Constructeur par d�faut
* Instancie un grpahe sans sommet ni arc.
*/
Cgraphe::Cgraphe()
{
	uiGRANbSommet = 0;
}


/**
* Cr�er un graphe a partir d'un nom de fichier
*/
Cgraphe::Cgraphe(char cNomFichier[256])
{
	unsigned int *uiNbArc = new unsigned int();
	unsigned int *uiNbSommet = new unsigned int();
	unsigned int * puiTabNumeroSommet;//; = new unsigned int[3];
	unsigned int ** ppuiTabDestinationArc;
	Cfichier FICFichier1;

	//lire le nb d'arcs et de sommets dans le fichier
	FICFichier1.FICLireNbSomArc(cNomFichier, uiNbArc, uiNbSommet);

	//Allocation tableau des numeros des sommets
	puiTabNumeroSommet = new unsigned int[*uiNbSommet];

	//Allocation tableau des destination des arcs
	ppuiTabDestinationArc = new unsigned int*[*uiNbArc];
	for (unsigned int uiCpt = 0; uiCpt < *uiNbArc; uiCpt++)
	{
		ppuiTabDestinationArc[uiCpt] = new unsigned int[2];
	}

	FICFichier1.FICLireNumeroSommet(cNomFichier, puiTabNumeroSommet, uiNbArc, uiNbSommet);
	FICFichier1.FICLireDestinationArc(cNomFichier, ppuiTabDestinationArc, uiNbArc, uiNbSommet);

	Csommet *SOMNouveauSommet;
	for (unsigned int uiCpt = 0; uiCpt < *uiNbSommet; uiCpt++) 
	{
		uiGRANbSommet++;
		ppSOMGRATableauSommets = (Csommet**)realloc(ppSOMGRATableauSommets, uiGRANbSommet * sizeof(Csommet));

		SOMNouveauSommet = new Csommet(puiTabNumeroSommet[uiCpt]);
		ppSOMGRATableauSommets[uiCpt] = SOMNouveauSommet;
	}

	// ppuiTabDestinationArc
	int iIndexDep;
	int iIndexArr;

	for (unsigned int uiCptLigne = 0; uiCptLigne < *uiNbArc; uiCptLigne++) 
	{
		iIndexDep = -1;
		iIndexArr = -1;
		for (unsigned int uiCptCol = 0; uiCptCol < 2; uiCptCol++) 
		{
			for (unsigned int uiCptSommetGraphe = 0; uiCptSommetGraphe < uiGRANbSommet; uiCptSommetGraphe++)
			{
				if (ppSOMGRATableauSommets[uiCptSommetGraphe]->SOMLireSommet() == ppuiTabDestinationArc[uiCptLigne][uiCptCol]) {
					if (iIndexDep == -1) {
						iIndexDep = uiCptSommetGraphe;
					}
					else {
						iIndexArr = uiCptSommetGraphe;
					}
				}
			}
		}
		// On ajoute l'arc
		if ((iIndexDep != -1) && (iIndexArr != -1)) {
			this->GRAAjouterArc(*ppSOMGRATableauSommets[iIndexDep], *ppSOMGRATableauSommets[iIndexArr]);
		}
	}

}


/**
* Constructeur de recopie d'un graphe
* fait exactement la m�me chose que la surcharge de l'op�rateur=
*/
Cgraphe::Cgraphe(Cgraphe & GRAGrapheACopier)
{
	uiGRANbSommet = 0;
	ppSOMGRATableauSommets = nullptr;
	unsigned int uiNbArcGrapheACopier = 0;
	//parcourt des sommets du premier graphe 
	unsigned int uiNbSommet = GRAGrapheACopier.GRALireNbSommet();
	for (unsigned int uiCptSommet = 0; uiCptSommet < uiNbSommet; uiCptSommet++)
	{
		//pour chaque sommet, on en cr�e un nouveau dans le GrapheACopier
		unsigned int uiNumSommet = GRAGrapheACopier.GRALireTableauSommet(uiCptSommet)->SOMLireSommet();
		this->GRAAjouterSommet(*(new Csommet(uiNumSommet)));

		//On compte le nb d'arc dans le graphe a copier
		uiNbArcGrapheACopier += GRAGrapheACopier.GRALireTableauSommet(uiCptSommet)->SOMLireNbArrivant();

	}

	unsigned int ** ppuiTabGrapheACopier = new unsigned int*[uiNbArcGrapheACopier];
	for (unsigned int i = 0; i < uiNbArcGrapheACopier; i++) {
		ppuiTabGrapheACopier[i] = new unsigned int[2];
	}

	GRAGrapheACopier.GRALireTableauSommet(0);
	unsigned int uiIndice = 0;
	for (unsigned int uiCptSommet = 0; uiCptSommet < uiNbSommet; uiCptSommet++)
	{
		//sur chacun de ces nouveau sommet, il faut cr�er les tableaux d'arcs qui correspondent avec l'ancien graphe
		unsigned int uiNbPartant = GRAGrapheACopier.GRALireTableauSommet(uiCptSommet)->SOMLireNbPartant();

		for (unsigned int uiCptPartant = 0; uiCptPartant < uiNbPartant; uiCptPartant++) {
			ppuiTabGrapheACopier[uiIndice][0] = GRAGrapheACopier.GRALireTableauSommet(uiCptSommet)->SOMLireSommet();//GRAGrapheACopier.GRALireTableauSommet(uiCptSommet)->SOMLireArcPartant(uiCptPartant)->ARCLireDepart();
			ppuiTabGrapheACopier[uiIndice][1] = GRAGrapheACopier.GRALireTableauSommet(uiCptSommet)->SOMLireArcPartant(uiCptPartant)->ARCLireDestination();
			uiIndice++;
		}
	}


	int iIndexDep;
	int iIndexArr;
	// On parcourt le tableau qui contient les depart/destinations des arcs
	for (unsigned int uiCptLigne = 0; uiCptLigne < uiNbArcGrapheACopier; uiCptLigne++)
	{
		iIndexDep = -1;
		iIndexArr = -1;
		for (unsigned int uiCptCol = 0; uiCptCol < 2; uiCptCol++)
		{
			// Pour chaque case on regarde a quel indice se trouve le sommet dans le tableau de sommet du graphe
			for (unsigned int uiCptSommetGraphe = 0; uiCptSommetGraphe < uiGRANbSommet; uiCptSommetGraphe++)
			{
				if (ppSOMGRATableauSommets[uiCptSommetGraphe]->SOMLireSommet() == ppuiTabGrapheACopier[uiCptLigne][uiCptCol]) {
					// Si le depart est d�j� trouv� alors on rempli l'indice d'arriv�
					if (iIndexDep == -1) {
						iIndexDep = uiCptSommetGraphe;
					}
					else {
						iIndexArr = uiCptSommetGraphe;
					}
				}
			}
		}
		// Quand on a les deux indices on ajoute l'arc
		if ((iIndexDep != -1) && (iIndexArr != -1)) {
			this->GRAAjouterArc(*ppSOMGRATableauSommets[iIndexDep], *ppSOMGRATableauSommets[iIndexArr]);

		}
	}

	// D�sallocation du tableau temporaire
	for (unsigned int i = 0; i < uiNbArcGrapheACopier; i++) {
		delete ppuiTabGrapheACopier[i];
	}
	delete[] ppuiTabGrapheACopier;
}


/**
* D�salloue le tableau de sommets et les tableaux d'arcs de chaque sommets
*/
Cgraphe::~Cgraphe()
{
	for (unsigned int uiCpt = 0; uiCpt < uiGRANbSommet; uiCpt++) {
		ppSOMGRATableauSommets[uiCpt]->desallocSOMTableauPartant();
		ppSOMGRATableauSommets[uiCpt]->desallocSOMTableauArrivant();
		if (ppSOMGRATableauSommets[uiCpt] != nullptr) {
			delete ppSOMGRATableauSommets[uiCpt];
			ppSOMGRATableauSommets[uiCpt] = nullptr;
		}
		
	}
	delete[] ppSOMGRATableauSommets;
	ppSOMGRATableauSommets = nullptr;
	uiGRANbSommet = 0;
}


/**
* Ajouter un sommet au graphe 
* @param SOMNouveauSommet r�f�rence vers le sommet � ajouter
*/
void Cgraphe::GRAAjouterSommet(Csommet & SOMNouveauSommet) 
{
	//on incremente le nombre de sommet dans le graphe
	uiGRANbSommet++;
	//on rajoute une case dans le tableau
	//if (ppSOMGRATableauSommets = nullptr) {
	//	cout <<"oui";
	//}
	ppSOMGRATableauSommets = (Csommet**)realloc(ppSOMGRATableauSommets, uiGRANbSommet * sizeof(Csommet));
	//on cree le pointeur vers le sommet que nous allons ajouter dan le tableau

	ppSOMGRATableauSommets[uiGRANbSommet - 1] = &SOMNouveauSommet;
	//return &SOMNouveauSommet;
}


/**
* Ajouter un arc dans le graphe
* @param SOMSommetDepart Le sommet de d�part de l'arc
* @param SOMSommetDestination Le sommet d'arriv� de l'arc
*/
void Cgraphe::GRAAjouterArc(Csommet & SOMSommetDepart, Csommet & SOMSommetDestination) 
{
	//On instancie un nouvel Arc
	Carc * NouvelArc;
	NouvelArc = new Carc(SOMSommetDestination.SOMLireSommet());//, SOMSommetDepart.SOMLireSommet());

	//On ajoute l'arc dans les tableau des arcs patants du sommet de depart
	//et dans le tableau des arcs arrivants du sommet d'arriv�
	//Peut �chouer si un arc pointant d�j� vers cette destination existe d�j� dans le tableau des arcs partants du sommet de depart
	SOMSommetDepart.SOMAjouteArcPartant(*NouvelArc);
	SOMSommetDestination.SOMAjouteArcArrivant(*NouvelArc);
	
}


/**
* Afficher le graphe dans la console
*/
void Cgraphe::GRAAfficherGraphe() 
{
	for (unsigned int uiCpt = 0; uiCpt < uiGRANbSommet; uiCpt++) 
	{
		if (ppSOMGRATableauSommets[uiCpt]->SOMLireNbPartant() == 0) {
			cout << "Le sommet " << (ppSOMGRATableauSommets[uiCpt])->SOMLireSommet() << " ne pointe aucun sommet";
			cout << endl;
		}
		else {
			cout << "Le sommet " << (ppSOMGRATableauSommets[uiCpt])->SOMLireSommet() << " pointe les sommets : ";
			(ppSOMGRATableauSommets[uiCpt])->SOMAfficherPartant();
		}

		cout << "Le sommet " << (ppSOMGRATableauSommets[uiCpt])->SOMLireSommet() << " est pointe par  : ";
		(ppSOMGRATableauSommets[uiCpt])->SOMAfficherNbArrivant();
		cout << " sommet(s)" << endl;
		cout << endl;

	}

}


/**
* Lire un sommet � une position pr�cise dans le tableau des sommets du graphe
* @param uiPosition La position a laquelle le sommet se trouve dans le tableau
* @return Csommet* - un pointeur vers le sommet a la position donn�e
*/
Csommet * Cgraphe::GRALireTableauSommet(unsigned int uiPosition) const
{
	return ((ppSOMGRATableauSommets[uiPosition]));
}


/**
* Supprimer un sommet du graphe
* @param uiSommetASupprimer Le num�ro du sommet � supprimer
*/
void Cgraphe::GRASupprimerSommet(unsigned int uiSommetASupprimer)
{
	if (uiGRANbSommet == 0)
	{	
		Cexception EXCAucunSommet;
		EXCAucunSommet.EXCModifierValeur(AUCUN_SOMMET);
		throw(EXCAucunSommet);
	}

	//On chercher d'abord l'index ou se trouve le sommet 
	bool SommetPresent = false;
	int iIndex = -1;
	for (unsigned int uiCpt = 0; uiCpt < uiGRANbSommet; uiCpt++) 
	{
		if (uiSommetASupprimer == ppSOMGRATableauSommets[uiCpt]->SOMLireSommet()) 
		{
			SommetPresent = true;
			iIndex = uiCpt;
		}
	}

	//on verifie qu'il est pr�sent avant de continuer
	if (SommetPresent == true) {
		//pour chaque sommet du graphe on efface ses arc partant etarrivant vers le sommet 
		for (unsigned int uiCpt = 0; uiCpt < uiGRANbSommet; uiCpt++)
		{
			//suppression des arcs partants
			unsigned int uiNbPartant = ppSOMGRATableauSommets[uiCpt]->SOMLireNbPartant();
			for (unsigned int uiCptPartant = 0; uiCptPartant < uiNbPartant; uiCptPartant++)
			{
				if (ppSOMGRATableauSommets[uiCpt]->SOMLireArcPartant(uiCptPartant)->ARCLireDestination() == uiSommetASupprimer) {
					ppSOMGRATableauSommets[uiCpt]->SOMSupprimerArcPartant(uiCptPartant);
				}
			}
			unsigned int uiNbArrivant = ppSOMGRATableauSommets[uiCpt]->SOMLireNbArrivant();
			for (unsigned int uiCptArrivant = 0; uiCptArrivant < uiNbArrivant; uiCptArrivant++)
			{
				if (ppSOMGRATableauSommets[uiCpt]->SOMLireSommet() == uiSommetASupprimer) {
					ppSOMGRATableauSommets[uiCpt]->SOMSupprimerArcArrivant(uiCptArrivant);
				}

			}
		}

		delete ppSOMGRATableauSommets[iIndex];
		
		for (unsigned int uiCptSommet = iIndex; uiCptSommet < uiGRANbSommet; uiCptSommet++) {
			ppSOMGRATableauSommets[uiCptSommet] = ppSOMGRATableauSommets[uiCptSommet + 1];
		}
		uiGRANbSommet--;
		ppSOMGRATableauSommets = (Csommet**)realloc(ppSOMGRATableauSommets, (uiGRANbSommet) * sizeof(Csommet*));
	}
	else
	{
		Cexception EXCSommetIntrouvable;
		EXCSommetIntrouvable.EXCModifierValeur(SOMMET_INTROUVABLE);
		throw(EXCSommetIntrouvable);
	}


}


/**
* Surcharge de la m�thode de suppression d'un sommet
* @param &SOM - r�f�rence vers le sommet � supprimer
*/
void Cgraphe::GRASupprimerSommet(Csommet & SOMSommetASupprimer)
{
	this->GRASupprimerSommet(SOMSommetASupprimer.SOMLireSommet());
}


/**/
void Cgraphe::GRAModifierSommet(unsigned int uiAncienNumeroSommet, unsigned int uiNouveauNumeroSommet)
{
	int uiPosition = -1;
	for (unsigned int uiCpt = 0; uiCpt < uiGRANbSommet; uiCpt++) {
		if (ppSOMGRATableauSommets[uiCpt]->SOMLireSommet() == uiAncienNumeroSommet) {
			uiPosition = uiCpt;
		}
		if (ppSOMGRATableauSommets[uiCpt]->SOMLireSommet() == uiNouveauNumeroSommet) {
			uiPosition = -2;
		}
	}
	if (uiPosition == -1) {
		Cexception EXCSommetIntrouvable;
		EXCSommetIntrouvable.EXCModifierValeur(SOMMET_INTROUVABLE);
		throw(EXCSommetIntrouvable);
	}
	if (uiPosition == -2) {
		//exception
		Cexception EXCSommetExistant;
		EXCSommetExistant.EXCModifierValeur(SOMMET_EXISTANT);
		throw(EXCSommetExistant);
	}

	ppSOMGRATableauSommets[uiPosition]->SOMModifierNumero(uiNouveauNumeroSommet);

	//pour chaque sommet du graphe on efface ses arc partant etarrivant vers le sommet 
	for (unsigned int uiCpt = 0; uiCpt < uiGRANbSommet; uiCpt++)
	{
		//suppression des arcs partants
		unsigned int uiNbPartant = ppSOMGRATableauSommets[uiCpt]->SOMLireNbPartant();
		for (unsigned int uiCptPartant = 0; uiCptPartant < uiNbPartant; uiCptPartant++)
		{
			if (ppSOMGRATableauSommets[uiCpt]->SOMLireArcPartant(uiCptPartant)->ARCLireDestination() == uiAncienNumeroSommet) {
				ppSOMGRATableauSommets[uiCpt]->SOMModifierArcPartant(uiCptPartant, uiNouveauNumeroSommet);
			}
		}
		unsigned int uiNbArrivant = ppSOMGRATableauSommets[uiCpt]->SOMLireNbArrivant();
		for (unsigned int uiCptArrivant = 0; uiCptArrivant < uiNbArrivant; uiCptArrivant++)
		{
			if (ppSOMGRATableauSommets[uiCpt]->SOMLireSommet() == uiAncienNumeroSommet) {
				ppSOMGRATableauSommets[uiCpt]->SOMModifierArcArrivant(uiCptArrivant, uiNouveauNumeroSommet);
			}

		}
	}

}

Cgraphe Cgraphe::GRAInverserArcs(void) 
{
	Cgraphe GRAInverse;

	unsigned int uiNbArcs = 0;

	Csommet *SOMNouveauSommet;
	for (unsigned int uiCptSommet = 0; uiCptSommet < uiGRANbSommet; uiCptSommet++) {
		//uiGRANbSommet++;
		//ppSOMGRATableauSommets = (Csommet**)realloc(ppSOMGRATableauSommets, uiGRANbSommet * sizeof(Csommet));
		SOMNouveauSommet = new Csommet(ppSOMGRATableauSommets[uiCptSommet]->SOMLireSommet());
		//ppSOMGRATableauSommets[uiCptSommet] = SOMNouveauSommet;
		GRAInverse.GRAAjouterSommet(*SOMNouveauSommet);
		unsigned int uiNbPartant = ppSOMGRATableauSommets[uiCptSommet]->SOMLireNbPartant();
		for (unsigned int uiCptPartant = 0; uiCptPartant < uiNbPartant; uiCptPartant++) {
			uiNbArcs++;
		}
	}

	// On alloue un tableau qui contiendra les destinations et les d�parts des arcs
	unsigned int ** ppuiTabArcs = new unsigned int*[uiNbArcs];
	for (unsigned int uiCpt = 0; uiCpt < uiNbArcs; uiCpt++) {
		ppuiTabArcs[uiCpt] = new unsigned int[2];
	}

	unsigned int uiCpt = 0;
	for (unsigned int uiCptSommet = 0; uiCptSommet < uiGRANbSommet; uiCptSommet++) {
		unsigned int uiNbPartant = ppSOMGRATableauSommets[uiCptSommet]->SOMLireNbPartant();
		for (unsigned int uiCptPartant = 0; uiCptPartant < uiNbPartant; uiCptPartant++) {
			ppuiTabArcs[uiCpt][0] = ppSOMGRATableauSommets[uiCptSommet]->SOMLireSommet();
			ppuiTabArcs[uiCpt][1] = ppSOMGRATableauSommets[uiCptSommet]->SOMLireArcPartant(uiCptPartant)->ARCLireDestination();
			uiCpt++;
		}
	}

	unsigned int temp;
	for (unsigned int uiCptSommet = 0; uiCptSommet < uiNbArcs; uiCptSommet++, uiCpt++) {
		temp = ppuiTabArcs[uiCptSommet][0];
		ppuiTabArcs[uiCptSommet][0] = ppuiTabArcs[uiCptSommet][1];
		ppuiTabArcs[uiCptSommet][1] = temp;
	}


	int iIndexDep;
	int iIndexArr;

	

	// On parcourt le tableau qui contient les depart/destinations des arcs
	for (unsigned int uiCptLigne = 0; uiCptLigne < uiNbArcs; uiCptLigne++)
	{
		iIndexDep = -1;
		iIndexArr = -1;
		for (unsigned int uiCptCol = 0; uiCptCol < 2; uiCptCol++)
		{
			// Pour chaque case on regarde a quel indice se trouve le sommet dans le tableau de sommet du graphe
			for (unsigned int uiCptSommetGraphe = 0; uiCptSommetGraphe < uiGRANbSommet; uiCptSommetGraphe++)
			{
				if (ppSOMGRATableauSommets[uiCptSommetGraphe]->SOMLireSommet() == ppuiTabArcs[uiCptLigne][uiCptCol]) {
					// Si le depart est d�j� trouv� alors on rempli l'indice d'arriv�
					if (iIndexDep == -1) {
						iIndexDep = uiCptSommetGraphe;
					}
					else {
						iIndexArr = uiCptSommetGraphe;
					}
				}
			}
		}
		// Quand on a les deux indices on ajoute l'arc
		if ((iIndexDep != -1) && (iIndexArr != -1)) {
			//GRAAjouterArc(*ppSOMGRATableauSommets[iIndexDep], *ppSOMGRATableauSommets[iIndexArr]);
			GRAInverse.GRAAjouterArc(*GRAInverse.GRALireTableauSommet(iIndexDep), *GRAInverse.GRALireTableauSommet(iIndexArr));
		}
	}

	//GRAInverse.GRAAfficherGraphe();

	for (unsigned int uiCpt = 0; uiCpt < uiNbArcs; uiCpt++) {
		if (ppuiTabArcs[uiCpt] != nullptr) {
			delete ppuiTabArcs[uiCpt];
			ppuiTabArcs[uiCpt] = nullptr;
		}
	}
	delete[] ppuiTabArcs;

	return GRAInverse;
}


/**
* Retourne le nombre de sommet du graphe
* @return (unsigned int)
*/
unsigned int Cgraphe::GRALireNbSommet(void) const
{
	return uiGRANbSommet;
}


/**
* Surcharge de l'operateur d'affectation = 
*/
void Cgraphe::operator=(const Cgraphe & GRAGrapheACopier)
{
	this->~Cgraphe();
	unsigned int uiNbArcGrapheACopier = 0;
	//parcourt des sommets du premier graphe 
	unsigned int uiNbSommet = GRAGrapheACopier.GRALireNbSommet();
	Csommet * SOMNouveauSommet;
	for (unsigned int uiCptSommet = 0; uiCptSommet < uiNbSommet; uiCptSommet++)
	{
		//pour chaque sommet, on en cr�e un nouveau dans le GrapheACopier
		unsigned int uiNumSommet = GRAGrapheACopier.GRALireTableauSommet(uiCptSommet)->SOMLireSommet();
		SOMNouveauSommet = new Csommet(uiNumSommet);
		this->GRAAjouterSommet(*SOMNouveauSommet);

		//On compte le nb d'arc dans le graphe a copier
		uiNbArcGrapheACopier += GRAGrapheACopier.GRALireTableauSommet(uiCptSommet)->SOMLireNbArrivant();

	}

	unsigned int ** ppuiTabGrapheACopier = new unsigned int*[uiNbArcGrapheACopier];
	for (unsigned int i = 0; i < uiNbArcGrapheACopier; i++) {
		ppuiTabGrapheACopier[i] = new unsigned int[2];
	}

	//GRAGrapheACopier.GRALireTableauSommet(0);
	unsigned int uiIndice= 0;
	for (unsigned int uiCptSommet = 0; uiCptSommet < uiNbSommet; uiCptSommet++)
	{
		//sur chacun de ces nouveau sommet, il faut cr�er les tableaux d'arcs qui correspondent avec l'ancien graphe
		unsigned int uiNbPartant = GRAGrapheACopier.GRALireTableauSommet(uiCptSommet)->SOMLireNbPartant();
		
		for (unsigned int uiCptPartant = 0; uiCptPartant < uiNbPartant; uiCptPartant++) {
			ppuiTabGrapheACopier[uiIndice][0] = GRAGrapheACopier.GRALireTableauSommet(uiCptSommet)->SOMLireSommet();//;->SOMLireArcPartant(uiCptPartant)->ARCLireDepart();
			ppuiTabGrapheACopier[uiIndice][1] = GRAGrapheACopier.GRALireTableauSommet(uiCptSommet)->SOMLireArcPartant(uiCptPartant)->ARCLireDestination();
			uiIndice++; 
		}
	}


	int iIndexDep;
	int iIndexArr;
	// On parcourt le tableau qui contient les depart/destinations des arcs
	for (unsigned int uiCptLigne = 0; uiCptLigne < uiNbArcGrapheACopier; uiCptLigne++)
	{
		iIndexDep = -1;
		iIndexArr = -1;
		for (unsigned int uiCptCol = 0; uiCptCol < 2; uiCptCol++)
		{
			// Pour chaque case on regarde a quel indice se trouve le sommet dans le tableau de sommet du graphe
			for (unsigned int uiCptSommetGraphe = 0; uiCptSommetGraphe < uiGRANbSommet; uiCptSommetGraphe++)
			{
				if (ppSOMGRATableauSommets[uiCptSommetGraphe]->SOMLireSommet() == ppuiTabGrapheACopier[uiCptLigne][uiCptCol]) {
					// Si le depart est d�j� trouv� alors on rempli l'indice d'arriv�
					if (iIndexDep == -1) {
						iIndexDep = uiCptSommetGraphe;
					}
					else {
						iIndexArr = uiCptSommetGraphe;
					}
				}
			}
		}
		// Quand on a les deux indices on ajoute l'arc
		if ((iIndexDep != -1) && (iIndexArr != -1)) {
			this->GRAAjouterArc(*ppSOMGRATableauSommets[iIndexDep], *ppSOMGRATableauSommets[iIndexArr]);

		}
	}

	// D�sallocation du tableau temporaire
	for (unsigned int i = 0; i < uiNbArcGrapheACopier; i++) {
		delete ppuiTabGrapheACopier[i];
	}
	delete[] ppuiTabGrapheACopier;

}
